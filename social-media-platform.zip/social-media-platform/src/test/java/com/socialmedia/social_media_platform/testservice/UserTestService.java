package com.socialmedia.social_media_platform.testservice;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.socialmedia.dto.UserDTO;
import com.socialmedia.entity.User;
import com.socialmedia.repository.UserRepository;
import com.socialmedia.service.implementation.UserServiceImpl;

public class UserTestService {

	@Mock
	private UserRepository userRepository;

	@InjectMocks
	private UserServiceImpl userService; // class under test

	private User userEntity;
	private UserDTO userDTO;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);

		userEntity = new User();
		userEntity.setId(1L);
		userEntity.setUsername("sam");
		userEntity.setEmail("sam@test.com");
		userEntity.setPassword("password123");

		userDTO = new UserDTO(1L, "sam", "sam@test.com", "password123", "Male");
	}

	@Test
	void testCreateUser() {
		when(userRepository.save(any(User.class))).thenReturn(userEntity);

		UserDTO result = userService.createUser(userDTO);

		assertThat(result).isNotNull();
		assertThat(result.getUsername()).isEqualTo("sam");
		verify(userRepository, times(1)).save(any(User.class));
	}

	@Test
	void testGetUserById_Found() {
		when(userRepository.findById(1L)).thenReturn(Optional.of(userEntity));

		UserDTO result = userService.getUserById(1L);

		assertThat(result).isNotNull();
		assertThat(result.getEmail()).isEqualTo("sam@test.com");
	}

	@Test
	void testGetUserById_NotFound() {
		when(userRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(RuntimeException.class, () -> userService.getUserById(1L));
	}

	@Test
	void testGetAllUsers() {
		when(userRepository.findAll()).thenReturn(Collections.singletonList(userEntity));

		List<UserDTO> result = userService.getAllUsers();

		assertThat(result).hasSize(1);
		assertThat(result.get(0).getUsername()).isEqualTo("sam");
	}

	@Test
	void testUpdateUser_Success() {
		when(userRepository.findById(1L)).thenReturn(Optional.of(userEntity));
		when(userRepository.save(any(User.class))).thenReturn(userEntity);

		UserDTO updated = new UserDTO(1L, "sam_updated", "sam_updated@test.com", "newPass", "Female");

		UserDTO result = userService.updateUser(1L, updated);

		assertThat(result.getUsername()).isEqualTo("sam_updated");
		assertThat(result.getEmail()).isEqualTo("sam_updated@test.com");
	}

	@Test
	void testUpdateUser_NotFound() {
		when(userRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(RuntimeException.class, () -> userService.updateUser(1L, userDTO));
	}

	@Test
	void testDeleteUser_Success() {
		when(userRepository.existsById(1L)).thenReturn(true);
		doNothing().when(userRepository).deleteById(1L);

		userService.deleteUser(1L);

		verify(userRepository, times(1)).deleteById(1L);
	}

	@Test
	void testDeleteUser_NotFound() {
		when(userRepository.existsById(1L)).thenReturn(false);

		assertThrows(RuntimeException.class, () -> userService.deleteUser(1L));
	}

	@Test
	void testFollowUser_Success() {
		User user = new User();
		user.setId(1L);

		User followUser = new User();
		followUser.setId(2L);

		when(userRepository.findById(1L)).thenReturn(Optional.of(user));
		when(userRepository.findById(2L)).thenReturn(Optional.of(followUser));

		userService.followUser(1L, 2L);

		assertThat(user.getFollowing()).contains(followUser);
		assertThat(followUser.getFollowers()).contains(user);
	}

	@Test
	void testFollowUser_SameUser() {
		assertThrows(RuntimeException.class, () -> userService.followUser(1L, 1L));
	}

	@Test
	void testUnfollowUser_Success() {
		User user = new User();
		user.setId(1L);

		User followUser = new User();
		followUser.setId(2L);

		// simulate already following
		user.getFollowing().add(followUser);
		followUser.getFollowers().add(user);

		when(userRepository.findById(1L)).thenReturn(Optional.of(user));
		when(userRepository.findById(2L)).thenReturn(Optional.of(followUser));

		userService.unfollowUser(1L, 2L);

		assertThat(user.getFollowing()).doesNotContain(followUser);
		assertThat(followUser.getFollowers()).doesNotContain(user);
	}
}
