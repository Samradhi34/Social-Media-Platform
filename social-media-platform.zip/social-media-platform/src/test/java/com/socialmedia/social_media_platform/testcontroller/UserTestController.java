package com.socialmedia.social_media_platform.testcontroller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.socialmedia.controller.UserController;
import com.socialmedia.dto.UserDTO;
import com.socialmedia.service.UserService;

import lombok.extern.slf4j.Slf4j;

@WebMvcTest(UserController.class)  // It helps loads only controller layer
@Slf4j
public class UserTestController {
	
	@Autowired
    private MockMvc mockMvc;  //It helps us test API calls (GET/POST/DELETE...)

    @MockBean
    private UserService userService;  // mock service

    @Autowired
    private ObjectMapper objectMapper; // converts object -> JSON
    
    private UserDTO userDto;
    
    @BeforeEach
    void setUp() {
    	 
    	log.info("Inside setUp() method");
    	
        userDto = new UserDTO();
        userDto.setId(1L);
        userDto.setUsername("sam123");
        userDto.setEmail("sam@example.com");
        userDto.setPassword("password123");
    }
    
    @Test
    void testCreateUser() throws JsonProcessingException, Exception {
    	log.info("Inside testCreateUser() method");
    	
    	when(userService.createUser(userDto)).thenReturn(userDto);
    	
    	mockMvc.perform(post("/users/add-user")
    			.contentType(MediaType.APPLICATION_JSON)
    			.content(objectMapper.writeValueAsString(userDto)))
    	         .andExpect(status().isCreated())
    	         .andExpect(jsonPath("$.username").value("sam123"))
                 .andExpect(jsonPath("$.email").value("sam@example.com"));
    }
    
    @Test
    void testGetUserById() throws Exception {
    	log.info("Inside testGetUserById() method");
        when(userService.getUserById(1L)).thenReturn(userDto);

        mockMvc.perform(get("/users/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("sam123"))
                .andExpect(jsonPath("$.email").value("sam@example.com"));
    }

    @Test
    void testGetAllUsers() throws Exception {
    	log.info("Inside testGetAllUsers() method");
        List<UserDTO> users = Arrays.asList(userDto);
        when(userService.getAllUsers()).thenReturn(users);

        mockMvc.perform(get("/users/view-all-user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].username").value("sam123"));
    }

    @Test
    void testDeleteUser() throws Exception {
    	log.info("Inside testDeleteUser() method");
        doNothing().when(userService).deleteUser(1L);

        mockMvc.perform(delete("/users/delete-user/1"))
                .andExpect(status().isNoContent());
    }

}
