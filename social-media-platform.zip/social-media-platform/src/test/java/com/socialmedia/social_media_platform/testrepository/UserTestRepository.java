package com.socialmedia.social_media_platform.testrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.socialmedia.entity.User;

public interface UserTestRepository extends JpaRepository<User, Long>{
	
	

}
