package com.socialmedia.social_media_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialMediaPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
