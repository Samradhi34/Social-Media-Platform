package com.socialmedia.config;

import java.util.Arrays;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.oas.models.tags.Tag;

@Configuration
public class SwaggerConfig {
	
	@Bean
	public OpenAPI myCustomConfig() {
		return new OpenAPI()
				.info(          //set project info
						new Info()
						.title("Social Media Plateform")
						.description("By Samradhi pandit")
		         )
				.servers(         //Servers (Environments) define
						Arrays.asList(
						    (new Server().url("http://localhost:8085").description("local")),
						    (new Server().url("http://localhost:8086").description("live"))
					     )
				).tags(Arrays.asList(
						new Tag().name("User-Controller-API's"),
						new Tag().name("Post-Controller-API's"),
						new Tag().name("Comment-Controller-API's"),
						new Tag().name("Like-Controller-API's"),
						new Tag().name("Repost-Controller-API's")
					   )
				).addSecurityItem(new SecurityRequirement().addList("bearerAuth")) //Security (JWT Token Authentication)
				.components(new Components().addSecuritySchemes("bearerAuth",
						new SecurityScheme()
						.type(SecurityScheme.Type.HTTP)
						.scheme("bearer")
						.bearerFormat("JWT")
						.in(SecurityScheme.In.HEADER)
						.name("Authoriztion")
				));
	}

}
