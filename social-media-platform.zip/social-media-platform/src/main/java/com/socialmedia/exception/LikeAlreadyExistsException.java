package com.socialmedia.exception;

import lombok.Getter;

@Getter
public class LikeAlreadyExistsException extends RuntimeException{
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = -9165191026322341713L;

	public LikeAlreadyExistsException(String message) {
	        super(message);
	    }
	 
}
