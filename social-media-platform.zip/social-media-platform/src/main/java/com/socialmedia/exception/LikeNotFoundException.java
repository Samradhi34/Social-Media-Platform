package com.socialmedia.exception;

import lombok.Getter;

@Getter
public class LikeNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8360224133619792728L;

	public LikeNotFoundException(String message){
		super(message);
	}
}
