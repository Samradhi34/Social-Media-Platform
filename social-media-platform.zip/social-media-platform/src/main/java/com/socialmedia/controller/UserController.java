package com.socialmedia.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.socialmedia.dto.UserDTO;
import com.socialmedia.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Tag(name = "User", description = "User management API's")
@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {
	
	private final UserService userService;
	
	/**
	 * Create User
	 * @param userDTO
	 * @return
	 */
	@Operation(summary = "Add User")
	@PostMapping("/add-user")
    public ResponseEntity<?> createUser(@Valid @RequestBody UserDTO userDTO) {
        return ResponseEntity.ok(userService.createUser(userDTO));
    }
	
	/**
	 * Get User By Id
	 * @param id
	 * @return
	 */
	@Operation(summary = "Get User By Id")
	@GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }
	
	/**
	 * Get All Users
	 * @return
	 */
	@Operation(summary = "Get All Users")
	@GetMapping
    public ResponseEntity<?> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }
	
	/**
	 * Update Users
	 * @param id
	 * @param userDTO
	 * @return
	 */
	@Operation(summary = "Update Users")
	@PutMapping("/{id}")
    public ResponseEntity<?> updateUser(
            @PathVariable Long id,
            @Valid @RequestBody UserDTO userDTO
    ) {
        return ResponseEntity.ok(userService.updateUser(id, userDTO));
    }
	
	/**
	 * Delete User
	 * @param id
	 * @return
	 */
	@Operation(summary = "Delete User")
	@DeleteMapping("/delete-user/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully");
    }
	
	/**
	 * Follow User
	 * @param userId
	 * @param followId
	 * @return
	 */
	@Operation(summary = "Follow User")
	@PostMapping("/{userId}/follow/{followId}")
	public ResponseEntity<?> followUser(@Valid
			@PathVariable Long userId,
			@PathVariable Long followId
	){
		userService.followUser(userId, followId);
		
		return ResponseEntity.ok("User : "+userId+" followed user : "+followId);
	}
	
	/**
	 * UnFollow User
	 * @param userId
	 * @param unfollowId
	 * @return
	 */
	@Operation(summary = "UnFollow User")
	@PostMapping("/{userId}/unfollow/{unfollowId}")
	public ResponseEntity<?> unfollowUser(
			@Valid
			@PathVariable Long userId,
			@PathVariable Long unfollowId
			){
		userService.unfollowUser(userId, unfollowId);
		
		return ResponseEntity.ok("User : "+userId+" unfollowed user : "+unfollowId);
	}

}
