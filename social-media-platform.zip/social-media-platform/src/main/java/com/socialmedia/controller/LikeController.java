package com.socialmedia.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.socialmedia.dto.LikeDTO;
import com.socialmedia.entity.Comment;
import com.socialmedia.entity.Post;
import com.socialmedia.entity.User;
import com.socialmedia.service.LikeService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@Tag(name = "Like", description = "Social Media Likes  API's")
@RestController
@RequestMapping("/like")
@RequiredArgsConstructor
public class LikeController {

	private final LikeService likeService;

	/**
	 * Like a post
	 * @param postId
	 * @param userId
	 * @return
	 */
	@Operation(summary = " Like a post")
	@PostMapping("/posts/{postId}/users/{userId}")
	public ResponseEntity<?> likePost(@PathVariable Long postId, @PathVariable Long userId) {
		User user = new User();
		user.setId(userId);

		Post post = new Post();
		post.setId(postId);

		LikeDTO likeDTO = likeService.likePost(user, post);
		return ResponseEntity.status(HttpStatus.CREATED).body(likeDTO);
	}

	/**
	 * Unlike a post
	 * @param postId
	 * @param userId
	 * @return
	 */
	@Operation(summary = " Unlike a post")
	@DeleteMapping("/posts/{postId}/users/{userId}")
	public ResponseEntity<?> unlikePost(@PathVariable Long postId, @PathVariable Long userId) {
		User user = new User();
		user.setId(userId);

		Post post = new Post();
		post.setId(postId);

		likeService.unlikePost(user, post);
		return ResponseEntity.noContent().build();
	}

	/**
	 * Like a Comment
	 * @param commentId
	 * @param userId
	 * @return
	 */
	@Operation(summary = " Like a Comment")
	@PostMapping("/comment/{commentId}/user/{userId}")
    public ResponseEntity<?> likeComment(
            @PathVariable Long commentId,
            @PathVariable Long userId
    ) {
        User user = new User();
        user.setId(userId);

        Comment comment = new Comment();
        comment.setId(commentId);

        LikeDTO likeDTO = likeService.likeComment(user, comment);
        return ResponseEntity.status(HttpStatus.CREATED).body(likeDTO);
    }

	/**
	 * Unlike a Comment
	 * @param commentId
	 * @param userId
	 * @return
	 */
	@Operation(summary = "Unlike a Comment")
	@DeleteMapping("/comments/{commentId}/users/{userId}")
    public ResponseEntity<?> unlikeComment(
            @PathVariable Long commentId,
            @PathVariable Long userId
    ) {
        User user = new User();
        user.setId(userId);

        Comment comment = new Comment();
        comment.setId(commentId);

        likeService.unlikeComment(user, comment);
        return ResponseEntity.noContent().build();
    }

	/**
	 * Get all likes for a Post
	 * @param postId
	 * @return
	 */
	@Operation(summary = "Get all likes for a Post")
	@GetMapping("/{postId}")
    public ResponseEntity<?> getLikesByPost(@PathVariable Long postId) {
        Post post = new Post();
        post.setId(postId);

        List<LikeDTO> likes = likeService.getLikesByPost(post);
        return ResponseEntity.ok(likes);
    }


	/**
	 * Get all likes for a Comment
	 * @param commentId
	 * @return
	 */
	@Operation(summary = "Get all likes for a Comment")
	@GetMapping("/{commentId}")
    public ResponseEntity<?> getLikesByComment(@PathVariable Long commentId) {
        Comment comment = new Comment();
        comment.setId(commentId);

        List<LikeDTO> likes = likeService.getLikesByComment(comment);
        return ResponseEntity.ok(likes);
    }

}
