package com.socialmedia.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.socialmedia.dto.CommentDTO;
import com.socialmedia.locale.MessageByLocaleService;
import com.socialmedia.response.GenericResponseHandlers;
import com.socialmedia.service.CommentService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/comment")
@RequiredArgsConstructor
public class CommentController {

	private final MessageByLocaleService messageByLocaleService;
	private final CommentService commentService;

	/**
	 * {
	 *  "content": "Wow, that was so good, u looking so preety in that dress",
	 *  "userId": 3, 
	 *  "postId": 7, "parentCommentId": null 
	 * }
	 * 
	 * @param commentDTO
	 * @return
	 */

	/**
	 *  Create comment
	 * @param commentDTO
	 * @return
	 */
	@PostMapping
	public ResponseEntity<?> createComment(@RequestBody CommentDTO commentDTO) {
		CommentDTO created = commentService.createComment(commentDTO);
		
		return new GenericResponseHandlers
				.Builder()
				.setData(created)
				.setMessage(messageByLocaleService.getMessage("create.success", new Object[] {"Comment"}))
				.setStatus(HttpStatus.CREATED).create();
	}

	/**
	 *  Get comment by ID
	 * @param id
	 * @return
	 */
	@GetMapping("/{id}")
	public ResponseEntity<?> getCommentById(@PathVariable("id") Long id) {
		CommentDTO comment = commentService.getCommentById(id);
		return new GenericResponseHandlers
				.Builder()
				.setData(comment)
				.setMessage(messageByLocaleService.getMessage("get.id", new Object[] {"Comment"}))
				.setStatus(HttpStatus.OK).create();
	}

	/**
	 *  Get all comments for a post
	 * @param postId
	 * @return
	 */
	@GetMapping("/{postId}")
	public ResponseEntity<?> getCommentsByPost(@PathVariable("postId") Long postId) {
		List<CommentDTO> comments = commentService.getCommentsByPostId(postId);
		return new GenericResponseHandlers
				.Builder()
				.setData(comments)
				.setMessage(messageByLocaleService.getMessage("post.id", new Object[] {"Comment"}))
				.setStatus(HttpStatus.OK).create();
	}

	/**
	 *  Update comment
	 * @param id
	 * @param commentDTO
	 * @return
	 */
	@PutMapping("/{id}")
	public ResponseEntity<?> updateComment(@PathVariable("id") Long id, @RequestBody CommentDTO commentDTO) {
		CommentDTO updated = commentService.updateComment(id, commentDTO);
		return new GenericResponseHandlers.Builder()
				.setData(updated)
				.setMessage(messageByLocaleService.getMessage("update.success", new Object[] {"Comment"} ))
				.setStatus(HttpStatus.OK).create();
	}

	/**
	 *  Delete comment
	 * @param id
	 * @return
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteComment(@PathVariable("id") Long id) {
		commentService.deleteComment(id);
		return ResponseEntity.noContent().build();
	}

}
