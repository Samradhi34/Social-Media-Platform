package com.socialmedia.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.socialmedia.dto.ReportDTO;
import com.socialmedia.service.ReportService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Tag(name = "Report", description = "Report management API's")
@RestController
@RequestMapping("/report")
@RequiredArgsConstructor
public class ReportController {

	public final ReportService reportService;

	/**
	 * Create new report
	 * @param reportDTO
	 * @return
	 */
	@Operation(summary = "Create new report")
	@PostMapping("/add-report")
	public ResponseEntity<?> createUser(@Valid @RequestBody ReportDTO reportDTO) {
		return ResponseEntity.ok(reportService.createReport(reportDTO));
	}

	/**
	 * Delete a report
	 * @param id
	 * @return
	 */
	@Operation(summary = "Delete a report")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteReport(@PathVariable Long id) {
		reportService.deleteReport(id);
		return ResponseEntity.noContent().build();
	}

	/**
	 * Get Report by Id
	 * @param id
	 * @return
	 */
	@Operation(summary = "Get Report by Id")
	@GetMapping("/{id}")
	public ResponseEntity<?> getReportById(@PathVariable("id") Long id) {
		return ResponseEntity.ok(reportService.getReportById(id));
	}

	/**
	 * Get All Reports
	 * @return
	 */
	@Operation(summary = "Get All Reports")
	@GetMapping
	public ResponseEntity<?> getAllReports() {
		return ResponseEntity.ok(reportService.getAllReports());
	}

}
