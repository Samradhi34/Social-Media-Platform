package com.socialmedia.controller;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.socialmedia.constants.MediaType;
import com.socialmedia.dto.PostDTO;
import com.socialmedia.exception.ResourceNotFoundException;
import com.socialmedia.service.PostService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Tag(name = "Post", description = "Social Media Post management API's")
@RestController
@RequestMapping("/post")
@RequiredArgsConstructor
public class PostController {

	private final PostService postService;

	/**
	 *  Create post
	 * @param userId
	 * @param content
	 * @param tags
	 * @param mediaFile
	 * @param mediaType
	 * @return
	 */
	@Operation(summary = "Add a post")
	@PostMapping(value = "/create-with-media", consumes = "multipart/form-data")
	public ResponseEntity<?> createPostWithMedia(@Valid @RequestParam Long userId, @RequestParam String content,
			@RequestParam(required = false) String tags, @RequestParam("mediaFile") MultipartFile mediaFile,
			@RequestParam("mediaType") MediaType mediaType) {

		PostDTO postWithMedia = postService.createPostWithMedia(userId, content, tags, mediaFile, mediaType);

		return ResponseEntity.status(HttpStatus.CREATED).body(postWithMedia);
	}

	/**
	 * Get all posts
	 * @return
	 */
	@Operation(summary = "Get all posts")
	@GetMapping
	public ResponseEntity<?> getAllPosts() {
		return ResponseEntity.ok(postService.getAllPosts());
	}

	/**
	 * Update Post
	 * @param postId
	 * @param userId
	 * @param content
	 * @param tags
	 * @param mediaFile
	 * @param mediaType
	 * @return
	 */
	@Operation(summary = "Update post")
	@PutMapping(value = "update/{postId}", consumes = "multipart/form-data")
	public ResponseEntity<?> updatePost(@Valid @PathVariable("postId") Long postId, @RequestParam Long userId,
			@RequestParam String content, @RequestParam(required = false) String tags,
			@RequestParam("mediaFile") MultipartFile mediaFile, @RequestParam("mediaType") MediaType mediaType) {

		PostDTO updatedPost = postService.updatePostWithMedia(postId, userId, content, tags, mediaFile, mediaType);

		return ResponseEntity.ok(updatedPost);

	}

	/**
	 * Delete post
	 * @param postId
	 * @return
	 */
	@Operation(summary = "Delete post")
	@DeleteMapping("/{postId}")
	public ResponseEntity<?> deletePost(@PathVariable("postId") Long postId) {
		postService.deletePost(postId);
		return ResponseEntity.noContent().build();
	}

	/**
	 * Repost post
	 * @param postId
	 * @param userId
	 * @return
	 */
	@Operation(summary = "Repost post")
	@PostMapping("/{postId}/repost/{userId}")
	public ResponseEntity<?> repostPost(@Valid @PathVariable("postId") Long postId,
			@PathVariable("userId") Long userId) {
		return ResponseEntity.ok(postService.repostPost(postId, userId));
	}

	/**
	 * Report post
	 * @param postId
	 * @param userId
	 * @return
	 */
	@Operation(summary = "Report post")
	@PostMapping("/{postId}/report/{userId}")
	public ResponseEntity<?> reportPost(@Valid @PathVariable("postId") Long postId, @PathVariable Long userId) {
		postService.reportPost(postId, userId);
		return ResponseEntity.ok().build();
	}

	/**
	 * Get user feed
	 * @param userId
	 * @param page
	 * @param size
	 * @return
	 */
	@Operation(summary = "Get user feed")
	@GetMapping("/feed/{userId}")
	public ResponseEntity<?> getUserFeed(@PathVariable("userId") Long userId,
			@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size) {
		return ResponseEntity.ok(postService.getUserFeed(userId, page, size));
	}

	/**
	 * Get posts of a user
	 * @param userId
	 * @return
	 */
	@Operation(summary = " Get posts of a user")
	@GetMapping("/byuser/{userId}")
	public ResponseEntity<?> getPostsByUser(@PathVariable("userId") Long userId) {
		return ResponseEntity.ok(postService.getPostByUserId(userId));
	}

	/**
	 * Save post
	 * @param postId
	 * @param userId
	 * @return
	 */
	@Operation(summary = "Save post")
	@PostMapping("/{postId}/save/{userId}")
	public ResponseEntity<?> savePost(@PathVariable("postId") Long postId, @PathVariable Long userId) {
		return ResponseEntity.ok(postService.savedPost(postId, userId));
	}

	/**
	 * Like/Unlike post
	 * @param postId
	 * @param userId
	 * @return
	 */
	@Operation(summary = "Like/Unlike post")
	@PostMapping("/{postId}/like/{userId}")
	public ResponseEntity<?> likePost(@PathVariable("postId") Long postId, @PathVariable Long userId) {
		return ResponseEntity.ok(postService.likePost(postId, userId));
	}
	
	/**
	 * Download media file of a post
	 *
	 * @param postId the ID of the post whose media needs to be downloaded
	 * @return ResponseEntity containing the media resource
	 */
	@Operation(summary = "Download media file of a post")
	@GetMapping("/media/{postId}")
	public ResponseEntity<Resource> downloadMedia(@PathVariable Long postId) {
	    // Fetch post
	    PostDTO post = postService.getPostById(postId);
	    if (post == null || post.getMedia() == null) {
	        throw new ResourceNotFoundException("Media not found for post ID: " + postId);
	    }

	    // Fetch actual media file as Resource
	    Resource resource = postService.getMediaFile(postId);
	    if (resource == null || !resource.exists()) {
	        throw new ResourceNotFoundException("Requested media file not found or not accessible");
	    }

	    /**
	     *  Infer content type safely
	     */
	    String contentType;
	    switch (post.getMedia().getMediaType()) {
	        case IMAGE -> contentType = "image/*";
	        case VIDEO -> contentType = "video/*";
	        case AUDIO -> contentType = "audio/*";
	        case DOCUMENT -> contentType = "application/*";
	        default -> contentType = "application/octet-stream";
	    }

	    /**
	     *  Return response with proper headers
	     */
	    return ResponseEntity.ok()
	            .header("Content-Disposition", "inline; filename=\"" + resource.getFilename() + "\"")
	            .header("Content-Type", contentType)
	            .body(resource);
	}


	
}
