package com.socialmedia.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.socialmedia.dto.MessageDTO;
import com.socialmedia.service.MessageService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@Tag(name = "Message", description = "Social Media message management API's")
@RestController
@RequestMapping("/api/msgs")
@RequiredArgsConstructor
public class MessageController {
	
	private final MessageService messageService;
	
	@Operation(summary = "Send a message")
	@PostMapping
    public ResponseEntity<MessageDTO> sendMessage(@RequestBody MessageDTO dto) {
        return ResponseEntity.ok(messageService.sendMessage(dto));
    }
	
	@Operation(summary = "Get messages sent by a user")
	@GetMapping("/sender/{senderId}")
    public ResponseEntity<List<MessageDTO>> getMessagesBySender(@PathVariable Long senderId) {
        return ResponseEntity.ok(messageService.getMessagesBySender(senderId));
    }

	@Operation(summary = "Get conversation between two user")
	@GetMapping("/receiver/{receiverId}")
    public ResponseEntity<List<MessageDTO>> getMessagesByReceiver(@PathVariable Long receiverId) {
        return ResponseEntity.ok(messageService.getMessagesByReceiver(receiverId));
    }
	
	@Operation(summary = "Mark message as read")
	@GetMapping("/conversation/{senderId}/{receiverId}")
    public ResponseEntity<List<MessageDTO>> getConversation(@PathVariable Long senderId, @PathVariable Long receiverId) {
        return ResponseEntity.ok(messageService.getConversation(senderId, receiverId));
    }
}
