package com.socialmedia.service.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.socialmedia.dto.CommentDTO;
import com.socialmedia.entity.Comment;
import com.socialmedia.entity.Post;
import com.socialmedia.entity.User;
import com.socialmedia.exception.ResourceNotFoundException;
import com.socialmedia.mapper.CommentMapper;
import com.socialmedia.repository.CommentRepository;
import com.socialmedia.repository.PostRepository;
import com.socialmedia.repository.UserRepository;
import com.socialmedia.service.CommentService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
@Transactional(rollbackFor = Throwable.class)
public class CommentServiceImpl implements CommentService {

	private final CommentRepository commentRepository;
	private final CommentMapper commentMapper;
	private final UserRepository userRepository;
	private final PostRepository postRepository;
//	private final MessageSource messageSource;

	@Override
	public CommentDTO getCommentById(Long id) {
		Comment comment = commentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Comment not found"));
		return commentMapper.entityToDTO(comment);
	}

	@Override
	public List<CommentDTO> getCommentsByPostId(Long postId) {
		Post post = postRepository.findById(postId).orElseThrow(() -> new ResourceNotFoundException("Post not found"));

		List<Comment> comments = commentRepository.findByPost(post);

		return comments.stream()
				.map(commentMapper::entityToDTO)
				.collect(Collectors.toList());
	}

	@Override
	public CommentDTO updateComment(Long id, CommentDTO commentDTO) {
		Comment comment = commentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Comment not found"));

		comment.setContent(commentDTO.getContent());

		Comment updated = commentRepository.save(comment);

		return commentMapper.entityToDTO(updated);
	}

	@Override
	public void deleteComment(Long id) {
		Comment comment = commentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Comment not found"));
		commentRepository.delete(comment);
	}

	@Override
	public CommentDTO createComment(CommentDTO commentDTO) {

		User user = userRepository.findById(commentDTO.getUserId())
				.orElseThrow(() -> new ResourceNotFoundException("User not found"));

		Post post = postRepository.findById(commentDTO.getPostId())
				.orElseThrow(() -> new ResourceNotFoundException("Post not found"));

		Comment comment = commentMapper.dtoToEntity(commentDTO);

		comment.setUser(user);
		comment.setPost(post);

		/**
		 * when a user is replying to another comment instead of creating a new
		 * top-level comment
		 */

		if (commentDTO.getParentCommentId() != null) {

			/**
			 * If it is not null, the user is replying to an existing comment.
			 * 
			 * If it is null, it’s a top-level comment , not a reply.
			 */

			Comment parent = commentRepository.findById(commentDTO.getParentCommentId())
					.orElseThrow(() -> new ResourceNotFoundException("Parent comment not found"));
			comment.setParentComment(parent);
		}

		Comment saveComment = commentRepository.save(comment);

		return commentMapper.entityToDTO(saveComment);

	}

}
