package com.socialmedia.service;

import java.util.List;

import com.socialmedia.dto.ReportDTO;

public interface ReportService {
	
	void deleteReport(Long reportId);

	List<ReportDTO> getAllReports();

	ReportDTO createReport(ReportDTO reportDTO);

	ReportDTO getReportById(Long id);

}
