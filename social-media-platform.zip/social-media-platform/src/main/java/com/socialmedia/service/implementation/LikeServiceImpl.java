package com.socialmedia.service.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.socialmedia.dto.LikeDTO;
import com.socialmedia.entity.Comment;
import com.socialmedia.entity.Like;
import com.socialmedia.entity.LikeId;
import com.socialmedia.entity.Post;
import com.socialmedia.entity.User;
import com.socialmedia.exception.LikeAlreadyExistsException;
import com.socialmedia.exception.LikeNotFoundException;
import com.socialmedia.mapper.LikeMapper;
import com.socialmedia.repository.LikeRepository;
import com.socialmedia.service.LikeService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Service
@Slf4j
@Transactional(rollbackFor = Throwable.class)
public class LikeServiceImpl implements LikeService {

	private final LikeRepository likeRepository;
	private final LikeMapper likeMapper;

	@Override
	public LikeDTO likePost(User user, Post post) {
		
		LikeId likeId = new LikeId(user.getId(), post.getId());
		
		/**
		 *  Check if like already exists using repository.findById or findByPostAndUser
		 */
        if (likeRepository.existsById(likeId)) {
            throw new LikeAlreadyExistsException("User " + user.getId() + " already liked Post " + post.getId());
        }
        
        Like like = Like.builder()
                .id(likeId)
                .user(user)
                .post(post)
                .build();
        
        likeRepository.save(like);

	    log.info("Post already liked by user!!");

		return likeMapper.entityToDTO(like);
	}
	
	@Override
	public LikeDTO likeComment(User user, Comment comment) {
		
		if (likeRepository.existsByUserAndComment(user, comment)) {
            throw new LikeAlreadyExistsException("User " + user.getId() + " already liked Comment " + comment.getId());
        }
		
		 /**
		  *  For composite id we can use userId  & commentId in LikeId ,if comment uses same composite
		  */
        Like likeEntity = Like.builder()
                .id(new LikeId(user.getId(), comment.getId()))
                .user(user)
                .comment(comment)
                .build();

        likeRepository.save(likeEntity);
        
        log.info("User ", user.getId()," liked Comment ", comment.getId());
        
		return likeMapper.entityToDTO(likeEntity);
	}

	@Override
	public void unlikePost(User user, Post post) {
		
		LikeId likeId = new LikeId(user.getId(), post.getId());
		
		 Like likeEntity = likeRepository.findById(likeId)
	                .orElseThrow(() -> new LikeNotFoundException(
	                        "Like not found for user " + user.getId() + " and post " + post.getId()));

		 likeRepository.delete(likeEntity);

	}


	@Override
	public void unlikeComment(User user, Comment comment) {
	    Like likeEntity = likeRepository.findByCommentAndUser(comment, user)
	            .orElseThrow(() -> new LikeNotFoundException(
	                    "Like not found for user " + user.getId() + " and comment " + comment.getId()));

	    likeRepository.delete(likeEntity);
	}

	@Override
	public List<LikeDTO> getLikesByPost(Post post) {
		return likeRepository.findByPost(post)
				.stream()
				.map(likeMapper::entityToDTO)
				.collect(Collectors.toList());
	}

	@Override
	public List<LikeDTO> getLikesByComment(Comment comment) {
		return likeRepository.findByComment(comment)
				.stream()
				.map(likeMapper::entityToDTO)
				.collect(Collectors.toList());
	}

}
