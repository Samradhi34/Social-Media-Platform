package com.socialmedia.service.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.socialmedia.dto.MessageDTO;
import com.socialmedia.entity.Message;
import com.socialmedia.entity.User;
import com.socialmedia.mapper.MessageMapper;
import com.socialmedia.repository.MessageRepository;
import com.socialmedia.repository.UserRepository;
import com.socialmedia.service.MessageService;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Service
@Slf4j            
@Transactional(rollbackFor = Throwable.class)   //by default rollback on RuntimeExceptions
public class MessageServiceImpl implements MessageService {

	private final MessageRepository messageRepository;
	private final MessageMapper messageMapper;
	private final UserRepository userRepository;

	@Override
	public MessageDTO sendMessage(MessageDTO msg) {
		User sender = userRepository.findById(msg.getSenderId())
				.orElseThrow(() -> new EntityNotFoundException("Sender not found"));

		User receiver = userRepository.findById(msg.getReceiverId())
				.orElseThrow(() -> new EntityNotFoundException("Receiver not found"));

		Message entity = messageMapper.dtoToEntity(msg, sender, receiver);
		Message saved = messageRepository.save(entity);

		return messageMapper.entityToDTO(saved);

	}

	@Override
	public List<MessageDTO> getMessagesBySender(Long senderId) {
		User sender = userRepository.findById(senderId)
				.orElseThrow(() -> new EntityNotFoundException("Sender not found"));

		return messageRepository.findBySender(sender).stream().map(messageMapper::entityToDTO)
				.collect(Collectors.toList());
	}

	@Override
	public List<MessageDTO> getMessagesByReceiver(Long receiverId) {
		User receiver = userRepository.findById(receiverId)
				.orElseThrow(() -> new EntityNotFoundException("Receiver not found"));

		return messageRepository.findByReceiver(receiver).stream().map(messageMapper::entityToDTO)
				.collect(Collectors.toList());
	}

	@Override
	public List<MessageDTO> getConversation(Long senderId, Long receiverId) {
		User sender = userRepository.findById(senderId)
				.orElseThrow(() -> new EntityNotFoundException("Sender not found"));

		User receiver = userRepository.findById(receiverId)
				.orElseThrow(() -> new EntityNotFoundException("Receiver not found"));

		return messageRepository.findBySenderAndReceiver(sender, receiver).stream().map(messageMapper::entityToDTO)
				.collect(Collectors.toList());
	}

}
