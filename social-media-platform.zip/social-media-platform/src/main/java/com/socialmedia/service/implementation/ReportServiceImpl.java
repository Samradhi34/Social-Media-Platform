package com.socialmedia.service.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.socialmedia.dto.ReportDTO;
import com.socialmedia.entity.Post;
import com.socialmedia.entity.Report;
import com.socialmedia.entity.User;
import com.socialmedia.exception.ResourceNotFoundException;
import com.socialmedia.mapper.ReportMapper;
import com.socialmedia.repository.PostRepository;
import com.socialmedia.repository.ReportRepository;
import com.socialmedia.repository.UserRepository;
import com.socialmedia.service.ReportService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Service
@Slf4j
@Transactional(rollbackFor = Throwable.class)
public class ReportServiceImpl implements ReportService {

	private final ReportRepository reportRepository;
	private final ReportMapper reportMapper;
	private final UserRepository userRepository;
	private final PostRepository postRepository;
	
	@Override
	public ReportDTO createReport(ReportDTO reportDTO) {
		
		User user = userRepository.findById(reportDTO.getUserId()).orElseThrow(()->new ResourceNotFoundException("User not found"));
		Post post = postRepository.findById(reportDTO.getPostId()).orElseThrow(()->new ResourceNotFoundException("Post not found"));
		
		Report report = ReportMapper.dtoToEntity(reportDTO);
		
		report.setUser(user);
		report.setPost(post);
		
		
		Report savedReport = reportRepository.save(report);
		return reportMapper.entityToDTO(savedReport);
	}

	@Override
	public ReportDTO getReportById(Long id) {
		Report user = reportRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("User not found with id: " + id));
		return reportMapper.entityToDTO(user);
	}

	@Override
	public List<ReportDTO> getAllReports() {
		return reportRepository.findAll().stream()
				.map(reportMapper::entityToDTO)
				.collect(Collectors.toList());
	}

	/**
	 *  Delete a Report
	 */
	@Override
	public void deleteReport(Long reportId) {
		if(!reportRepository.existsById(reportId)) {
			throw new ResourceNotFoundException("Report not found with id : "+reportId);
		}
		reportRepository.deleteById(reportId);
	}

}
