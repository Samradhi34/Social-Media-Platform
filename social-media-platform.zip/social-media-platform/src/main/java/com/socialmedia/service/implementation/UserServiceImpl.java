package com.socialmedia.service.implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.socialmedia.dto.UserDTO;
import com.socialmedia.entity.User;
import com.socialmedia.exception.ResourceNotFoundException;
import com.socialmedia.mapper.UserMapper;
import com.socialmedia.repository.UserRepository;
import com.socialmedia.service.UserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Transactional(rollbackFor = Throwable.class)
@Service
@Slf4j
public class UserServiceImpl implements UserService {

	private final UserRepository userRepository;
	private final UserMapper userMapper;

	@Override
	public UserDTO createUser(UserDTO userDTO) {

		log.info("Inside createUser() method in service");

		User userEntity = userMapper.dtoToEntity(userDTO);
		User savedUser = userRepository.save(userEntity);
		return userMapper.entityToDTO(savedUser);
	}

	@Override
	public UserDTO getUserById(Long id) {
		User user = userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
		return userMapper.entityToDTO(user);
	}

	@Override
	public List<UserDTO> getAllUsers() {
		return userRepository.findAll().stream().map(userMapper::entityToDTO).collect(Collectors.toList());
	}

	@Override
	public UserDTO updateUser(Long id, UserDTO userDTO) {

		log.info("Inside updateUser() method in service");

		User existingUser = userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));

		existingUser.setUsername(userDTO.getUsername());
		existingUser.setEmail(userDTO.getEmail());
		existingUser.setPassword(userDTO.getPassword());
		existingUser.setGender(userDTO.getGender());

		User updatedUser = userRepository.save(existingUser);
		return userMapper.entityToDTO(updatedUser);
	}

	@Override
	public void deleteUser(Long id) {
		if (!userRepository.existsById(id)) {
			throw new ResourceNotFoundException("User not found with id: " + id);
		}
		userRepository.deleteById(id);

	}

	@Override
	public void followUser(Long userId, Long followId) {

		/**
		 * user should not follow himself/herself
		 */
		if (userId.equals(followId)) {
			throw new ResourceNotFoundException("You cannot follow yourself with same UserId !!");
		}

		/**
		 * Fetch the user who wants to follow someone
		 */
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id : " + userId));

		/**
		 * Fetch the user who is going to be followed
		 */
		User followUser = userRepository.findById(followId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id : " + followId));

		/**
		 * Add the followUser to 'user's following list
		 */
		user.getFollowing().add(followUser);

		/**
		 * Now, Also add 'user' to followUser's followers list
		 */
		followUser.getFollowers().add(user);

		/**
		 * Save both users in the database
		 */
		userRepository.save(user);
		userRepository.save(followUser);

	}

	@Override
	public void unfollowUser(Long userId, Long unfollowId) {

		/**
		 *  Fetch the user who wants to unfollow
		 */
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("User not found: " + userId));

		/**
		 *  Fetch the user who is going to be unfollowed
		 */
		User unfollowUser = userRepository.findById(unfollowId)
				.orElseThrow(() -> new RuntimeException("User not found: " + unfollowId));

		/**
		 *  Remove unfollowUser from 'user's following list
		 */
		user.getFollowing().remove(unfollowUser);

		/**
		 *  Also remove 'user' from unfollowUser's followers list
		 */
		unfollowUser.getFollowers().remove(user);

		/**
		 *  Save both users in the database
		 */
		userRepository.save(user);
		userRepository.save(unfollowUser);

	}

}
