package com.socialmedia.service;

import java.util.List;

import com.socialmedia.dto.LikeDTO;
import com.socialmedia.entity.Comment;
import com.socialmedia.entity.Post;
import com.socialmedia.entity.User;

public interface LikeService {
	
	LikeDTO likePost(User user, Post post);

	void unlikePost(User user, Post post);
	

	LikeDTO likeComment(User user, Comment comment);

	void unlikeComment(User user, Comment comment);
	

	List<LikeDTO> getLikesByPost(Post post);

	List<LikeDTO> getLikesByComment(Comment comment);
}
