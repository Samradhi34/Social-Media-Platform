package com.socialmedia.service;

import java.util.List;

import com.socialmedia.dto.CommentDTO;

public interface CommentService {
	
	CommentDTO createComment(CommentDTO commentDTO);

    CommentDTO getCommentById(Long id);

    List<CommentDTO> getCommentsByPostId(Long postId);

    CommentDTO updateComment(Long id, CommentDTO commentDTO);

    void deleteComment(Long id);

}
