package com.socialmedia.service;

import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.web.multipart.MultipartFile;

import com.socialmedia.constants.MediaType;
import com.socialmedia.dto.PostDTO;
import com.socialmedia.entity.Post;

public interface PostService {


	PostDTO getPostById(Long postId);

	PostDTO savedPost(Long postId, Long userId);

	PostDTO likePost(Long postId, Long userId);

	List<PostDTO> getAllPosts();

	void deletePost(Long postId);

	PostDTO repostPost(Long postId, Long userId);

	void reportPost(Long postId, Long userId);

	Page<Post> getUserFeed(Long userId, int page, int size);

	List<Post> getPostByUserId(Long userId);

	PostDTO createPostWithMedia(Long userId, String content, String tags, MultipartFile mediaFile, MediaType mediaType);

	PostDTO updatePostWithMedia(Long postId, Long userId, String content, String tags, MultipartFile mediaFile,
			MediaType mediaType);

	Resource getMediaFile(Long postId);

}
