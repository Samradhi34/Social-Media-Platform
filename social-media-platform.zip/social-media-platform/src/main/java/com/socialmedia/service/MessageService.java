package com.socialmedia.service;

import java.util.List;

import com.socialmedia.dto.MessageDTO;

public interface MessageService {
	
	MessageDTO sendMessage(MessageDTO dto);

    List<MessageDTO> getMessagesBySender(Long senderId);

    List<MessageDTO> getMessagesByReceiver(Long receiverId);

    List<MessageDTO> getConversation(Long senderId, Long receiverId);

}
