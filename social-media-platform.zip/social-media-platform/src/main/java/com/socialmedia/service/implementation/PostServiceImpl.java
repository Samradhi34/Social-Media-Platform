package com.socialmedia.service.implementation;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.socialmedia.constants.MediaType;
import com.socialmedia.dto.PostDTO;
import com.socialmedia.entity.Like;
import com.socialmedia.entity.MediaResource;
import com.socialmedia.entity.Post;
import com.socialmedia.entity.Report;
import com.socialmedia.entity.User;
import com.socialmedia.exception.ResourceNotFoundException;
import com.socialmedia.mapper.PostMapper;
import com.socialmedia.repository.LikeRepository;
import com.socialmedia.repository.PostRepository;
import com.socialmedia.repository.UserRepository;
import com.socialmedia.service.PostService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
@Transactional(rollbackFor = Throwable.class)
public class PostServiceImpl implements PostService {

	private final PostRepository postRepository;
	private final UserRepository userRepository;
	private final LikeRepository likeRepository;
	private final PostMapper postMapper;

	/**
	 * 
	 * @param mediaFile - MultipartFile mediaFile → This is the uploaded file
	 *                  (image/video/audio) coming from Postman.
	 * @param userId
	 * @param content
	 * @param tags
	 * @param mediaType - kind of file it is (IMAGE, VIDEO, AUDIO).
	 * @return
	 */

	/**
	 *  Save the uploaded file to local storage -all files are stored in 'uploads/' folder
	 */
	@Value("${app.upload.dir}")
	private String uploadDir;

	@Override
	public PostDTO createPostWithMedia(Long userId, String content, String tags, MultipartFile mediaFile,
			MediaType mediaType) {

		/**
		 *  First, we will validating the input, If no file is sent then throw error.
		 */
		if (mediaFile == null || mediaFile.isEmpty()) {
			throw new IllegalArgumentException("Media file cannot be empty");
		}

		/**
		 *  File should not be bigger than 50MB , otherwise very large files can crash server
		 */
		if (mediaFile.getSize() > (50 * 1024 * 1024)) { // 50MB max
			throw new IllegalArgumentException("File size exceeds maximum allowed (50MB)");
		}

		/**
		 *  Here , We check content type matches it corresponding MediaType
		 */
		String contentType = mediaFile.getContentType();

		if (contentType == null) {
			throw new IllegalArgumentException("Invalid file type: NONE is not allowed");
		}

		switch (mediaType) {
		case IMAGE:
			if (!contentType.startsWith("image/")) {
				throw new IllegalArgumentException("Invalid file type: expected an image");
			}
			break;
		case VIDEO:
			if (!contentType.startsWith("video/")) {
				throw new IllegalArgumentException("Invalid file type: expected an video");
			}
			break;
		case AUDIO:
			if (!contentType.startsWith("audio/")) {
				throw new IllegalArgumentException("Invalid file type: expected an audio");
			}
			break;

		case DOCUMENT:
			if (!(contentType.startsWith("application/pdf") || contentType.startsWith("application/msword")
					|| contentType.startsWith("application/vnd.ms-excel") || contentType.startsWith("text/plain"))) {

				log.info("Cotent-Type of Document");
				log.debug(contentType);

				throw new IllegalArgumentException("Invalid file type: expected an document");
			}
			break;
		default:
			throw new IllegalArgumentException("Unexpected Media Type ");
		}

		/**
		 *  Now Check user exists - looks up the user in the DB and returns an
		    Optional<UserEntity> or else throw exception
		 */
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id : " + userId));

		/**
		 *  creates a Java File object representing the folder
		 */
		File directory = new File(uploadDir);

		/**
		 *  Makes sure the uploads/ folder exists
		 */
		if (!directory.exists()) {
			directory.mkdirs(); // create the folder if it doesn’t exist, including all missing parent folders.
		}

		/**
		 * Building a safe filename
		 */
		String original = mediaFile.getOriginalFilename(); // Get file’s original extension (.jpg, .mp4, etc)

		/**
		 * If no extension exists , it just returns an empty string.
		 */
		String extension = (original != null && original.contains(".")) ? original.substring(original.lastIndexOf("."))
				: "";

		/**
		 * now, Generate a UUID random name to avoid clashes.
		 */
		String safeName = UUID.randomUUID().toString() + extension;
		/**
		 * decide the complete storage path , where that file will live
		 */
		String filePath = uploadDir + File.separator + safeName;

		/**
		 * Save the file physically to computer’s storage, else throw error
		 */
		File desFile = new File(filePath);

		try {
			mediaFile.transferTo(desFile);
		} catch (IOException ex) {
			throw new RuntimeException("Failed to save uploaded file !!", ex);
		}

		/**
		 * Build a new PostEntity object for DB
		 */
		Post post = Post.builder().content(content) // post text.
				.tags(tags) // hashtags, keywords
				.media(new MediaResource(filePath, mediaType)) // store file path + media type
				.user(user) // who posted it
				.build();

		try {
			post = postRepository.save(post); // Save post into DB
		} catch (Exception e) {
			/**
			 * cleanup file, If DB save fails then , delete the uploaded file from disk
			 */
			if (desFile.exists()) {
				desFile.delete();
			}
			throw new RuntimeException("Failed to save post in DB!!" + e);
		}

		/**
		 *  Convert the PostEntity into PostDTO and return to controller
		 */
		return postMapper.entityToDTO(post);
	}

	@Override
	public PostDTO updatePostWithMedia(Long postId, Long userId, String content, String tags, MultipartFile mediaFile,
			MediaType mediaType) {

		/**
		 * Validate media file
		 */
		if (mediaFile == null || mediaFile.isEmpty()) {
			throw new IllegalArgumentException("Media file cannot be empty");
		}

		if (mediaFile.getSize() > (50 * 1024 * 1024)) {
			throw new IllegalArgumentException("File size exceeds maximum allowed (50MB)");
		}

		String contentType = mediaFile.getContentType();
		if (contentType == null) {
			throw new IllegalArgumentException("Invalid file type: NONE is not allowed");
		}

		switch (mediaType) {
		case IMAGE:
			if (!contentType.startsWith("image/")) {
				throw new IllegalArgumentException("Invalid file type: expected an image");
			}
			break;
		case VIDEO:
			if (!contentType.startsWith("video/")) {
				throw new IllegalArgumentException("Invalid file type: expected a video");
			}
			break;
		case AUDIO:
			if (!contentType.startsWith("audio/")) {
				throw new IllegalArgumentException("Invalid file type: expected an audio");
			}
			break;
		default:
			throw new IllegalArgumentException("Unexpected Media Type");
		}

		/**
		 * Validate user
		 */
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id : " + userId));

		/**
		 * Validate post
		 */
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post not found with id : " + postId));

		/**
		 * Ensure upload directory exists
		 */
		File directory = new File(uploadDir);
		if (!directory.exists()) {
			directory.mkdirs();
		}

		/**
		 * Generate safe filename
		 */
		String original = mediaFile.getOriginalFilename();
		String extension = (original != null && original.contains(".")) ? original.substring(original.lastIndexOf("."))
				: "";
		String safeName = UUID.randomUUID().toString() + extension;
		String filePath = uploadDir + File.separator + safeName;
		File desFile = new File(filePath);

		try {
			mediaFile.transferTo(desFile);
		} catch (IOException ex) {
			throw new RuntimeException("Failed to save uploaded file !!", ex);
		}

		/**
		 * Clean up old media file if exists
		 */
		MediaResource oldMedia = post.getMedia();
		if (oldMedia != null) {
			File oldFile = new File(oldMedia.getPath());
			if (oldFile.exists()) {
				oldFile.delete();
			}
		}

		/**
		 * Update post fields
		 */
		post.setContent(content);
		post.setTags(tags);
		post.setMedia(new MediaResource(filePath, mediaType));
		post.setUser(user); // Optional: only if ownership can change

		try {
			post = postRepository.save(post);
		} catch (Exception e) {
			if (desFile.exists()) {
				desFile.delete();
			}
			throw new RuntimeException("Failed to update post in DB!! " + e);
		}

		return postMapper.entityToDTO(post);
	}

	/**
	 * Get all posts
	 */
	@Override
	public List<PostDTO> getAllPosts() {
		return postRepository.findAll().stream().map(postMapper::entityToDTO).collect(Collectors.toList());
	}

	/**
	 * Delete post
	 */
	@Override
	public void deletePost(Long postId) {
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new RuntimeException("Post not found with id: " + postId));
		postRepository.delete(post);
	}

	/**
	 * Repost post
	 */
	@Override
	public PostDTO repostPost(Long postId, Long userId) {
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new RuntimeException("Post not found with id: " + postId));

		User user = userRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

		post.getRepostedBy().add(user);
		return postMapper.entityToDTO(postRepository.save(post));
	}

	/**
	 * Report post
	 */
	@Override
	public void reportPost(Long postId, Long userId) {
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new RuntimeException("Post not found with id: " + postId));

		User user = userRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

		Report report = new Report();

		report.setPost(post);
		report.setUser(user);

		post.getReports().add(report);

		if (post.getReports().size() > 5) {
			post.setDisabled(true);
		}

		postRepository.save(post);
	}

	/**
	 * Get user feed - only posts from current user & their followers
	 */
	public Page<Post> getUserFeed(Long userId, int page, int size) {
		User currentUser = userRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

		List<User> visibleUsers = new ArrayList<>();
		visibleUsers.add(currentUser);
		visibleUsers.addAll(currentUser.getFollowers());

		return postRepository.findByUserIn(visibleUsers, PageRequest.of(page, size, Sort.by("createdAt").descending()));
	}

	/**
	 * Get all posts of a specific user
	 */
	@Override
	public List<Post> getPostByUserId(Long userId) {
		return postRepository.findPostByUserId(userId);
	}

	/**
	 * Save a post for a user
	 */
	@Override
	public PostDTO savedPost(Long postId, Long userId) {
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new RuntimeException("Post not found with id: " + postId));

		User user = userRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

		/**
		 * Add post to saved posts
		 */
		user.getSavedPosts().add(post);
		userRepository.save(user);

		return postMapper.entityToDTO(post);
	}

	/**
	 * Like or Unlike post
	 */
	@Override
	public PostDTO likePost(Long postId, Long userId) {
		
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new RuntimeException("Post not found with id: " + postId));

		User user = userRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

		Like existingLike = likeRepository.findByPostAndUser(post, user);

		if (existingLike != null) {
			// Unlike if already liked
			post.getLikes().remove(existingLike);
			likeRepository.delete(existingLike);
		} else {
			// Like the post
			Like newLike = new Like();
			newLike.setPost(post);
			newLike.setUser(user);
			post.getLikes().add(newLike);
		}

		return postMapper.entityToDTO(postRepository.save(post));
	}

	/**
	 * Getting media file
	 */
	@Override
	public Resource getMediaFile(Long postId) {

		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("Post not found with id: " + postId));

		String filePath = post.getMedia().getPath();

		try {
			Path path = Paths.get(filePath).normalize();
			Resource resource = new UrlResource(path.toUri());

			if (!resource.exists() || !resource.isReadable()) {
				throw new RuntimeException("File not found: " + filePath);
			}

			return resource;
		} catch (MalformedURLException e) {
			throw new RuntimeException("Error while loading file: " + filePath, e);
		}
	}

	/**
	 * Get post by ID
	 */
	@Override
	public PostDTO getPostById(Long postId) {
		Post post = postRepository.findById(postId)
				.orElseThrow(() -> new RuntimeException("Post not found with id: " + postId));
		return postMapper.entityToDTO(post);

	}

}
