package com.socialmedia.specification;

import org.springframework.data.jpa.domain.Specification;

import com.socialmedia.entity.User;

/**
 * A Specification is like a filter builder that helps we create dynamic
 * database queries.
 */

public class UserSpecification {

	/**
	 *  Search doctors whose name contains given text
	 * @param name
	 * @return
	 */
	public static Specification<User> hasNameLike(String name) {
		return (root, query, cb) -> (name == null || name.isBlank()) ? null
				: cb.like(cb.lower(root.get("username")), "%" + name.toLowerCase() + "%");
	}

	/**
	 *  Search doctors whose email == given email
	 * @param email
	 * @return
	 */
	public static Specification<User> hasEmail(String email) {
		return (root, query, cb) -> (email == null || email.isBlank()) ? null
				: cb.equal(cb.lower(root.get("email")), "%" + email.toLowerCase() + "%");
	}

}
