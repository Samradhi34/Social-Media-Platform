package com.socialmedia.constants;

public enum MediaType {
	
	IMAGE,
	VIDEO,
	AUDIO,
	DOCUMENT,
	NONE
	
}
