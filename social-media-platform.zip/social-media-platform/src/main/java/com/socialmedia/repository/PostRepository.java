package com.socialmedia.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.socialmedia.entity.Post;
import com.socialmedia.entity.User;

public interface PostRepository extends JpaRepository<Post, Long> {

	Page<Post> findByUserIn(List<User> users, Pageable pageable);

	List<Post> findPostByUserId(Long userId);

	Page<Post> findByUserIn(List<User> visibleUsers, PageRequest of);

}
