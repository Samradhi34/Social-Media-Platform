package com.socialmedia.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.socialmedia.entity.Comment;
import com.socialmedia.entity.Like;
import com.socialmedia.entity.LikeId;
import com.socialmedia.entity.Post;
import com.socialmedia.entity.User;

public interface LikeRepository extends JpaRepository<Like, LikeId>{

	Like findByPostAndUser(Post post, User user);

    Optional<Like> findByCommentAndUser(Comment comment, User user);

	List<Like> findByPost(Post post);
	
	List<Like> findByComment(Comment comment);

	boolean existsByUserAndComment(User user, Comment comment);


}
