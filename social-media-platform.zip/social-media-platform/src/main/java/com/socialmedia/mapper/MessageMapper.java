package com.socialmedia.mapper;

import org.springframework.beans.BeanUtils;

import com.socialmedia.dto.MessageDTO;
import com.socialmedia.entity.Message;
import com.socialmedia.entity.User;

public class MessageMapper {

	public MessageDTO entityToDTO(Message entity) {
		if (entity == null)
			return null;

		MessageDTO dto = new MessageDTO();
		BeanUtils.copyProperties(entity, dto);

		dto.setSenderId(entity.getSender().getId());
		dto.setReceiverId(entity.getReceiver().getId());

		return dto;
	}

	public Message dtoToEntity(MessageDTO dto, User sender, User receiver) {
		if (dto == null)
			return null;

		Message entity = new Message();
		BeanUtils.copyProperties(dto, entity);

		entity.setSender(sender);
		entity.setReceiver(receiver);

		return entity;
	}

}
