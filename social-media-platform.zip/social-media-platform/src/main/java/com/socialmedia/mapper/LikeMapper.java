package com.socialmedia.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.socialmedia.dto.LikeDTO;
import com.socialmedia.entity.Like;

@Component
public class LikeMapper {

	/**
	 *  Convert Entity to DTO
	 * @param likeEntity
	 * @return
	 */

	public LikeDTO entityToDTO(Like likeEntity) {

		if (likeEntity == null)
			return null;

		LikeDTO likeDTO = new LikeDTO();

		BeanUtils.copyProperties(likeEntity, likeDTO);
		
		if (likeEntity.getUser() != null) {
            likeDTO.setUserId(likeEntity.getUser().getId());
        }
        if (likeEntity.getPost() != null) {
            likeDTO.setPostId(likeEntity.getPost().getId());
        }
        if (likeEntity.getComment() != null) {
            likeDTO.setCommentId(likeEntity.getComment().getId());
        }
        
        //for composite ID's userId/postId 
        if (likeEntity.getId() != null) {
            if (likeDTO.getUserId() == null) {
                likeDTO.setUserId(likeEntity.getId().getUserId());
            }
            if (likeDTO.getPostId() == null) {
                likeDTO.setPostId(likeEntity.getId().getPostId());
            }
        }
		
		return likeDTO;

	}

	/**
	 *  Convert DTO to entity
	 * @param likeDTO
	 * @return
	 */

	public  Like dtoToEntity(LikeDTO likeDTO) {

		if (likeDTO == null)
			return null;

		Like likeEntity = new Like();

		BeanUtils.copyProperties(likeDTO, likeEntity);

		return likeEntity;

	}

}
