package com.socialmedia.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.socialmedia.dto.ReportDTO;
import com.socialmedia.entity.Report;

@Component
public class ReportMapper {

	// Convert Entity to DTO

	public ReportDTO entityToDTO(Report reportEntity) {

		if (reportEntity == null)
			return null;

		ReportDTO reportDTO = new ReportDTO();

		BeanUtils.copyProperties(reportEntity, reportDTO);

		// manual mapping for foreign keys
		reportDTO.setUserId(reportEntity.getUser() != null ? reportEntity.getUser().getId() : null);
		reportDTO.setPostId(reportEntity.getPost() != null ? reportEntity.getPost().getId() : null);

		return reportDTO;

	}

	// Convert DTO to entity

	public static Report dtoToEntity(ReportDTO reportDTO) {

		if (reportDTO == null)
			return null;

		Report reportEntity = new Report();

		BeanUtils.copyProperties(reportDTO, reportEntity);

		return reportEntity;

	}

}
