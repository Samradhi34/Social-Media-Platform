package com.socialmedia.mapper;

import org.springframework.beans.BeanUtils;

import com.socialmedia.dto.CommentDTO;
import com.socialmedia.entity.Comment;

public class CommentMapper {

	// Convert Entity to DTO

	public CommentDTO entityToDTO(Comment commentEntity) {

		if (commentEntity == null)
			return null;

		CommentDTO commentDTO = new CommentDTO();

		BeanUtils.copyProperties(commentEntity, commentDTO);

		return commentDTO;

	}

	// Convert DTO to entity

	public  Comment dtoToEntity(CommentDTO commentDTO) {

		if (commentDTO == null)
			return null;

		Comment commentEntity = new Comment();

		BeanUtils.copyProperties(commentDTO, commentEntity);

		return commentEntity;

	}
}
