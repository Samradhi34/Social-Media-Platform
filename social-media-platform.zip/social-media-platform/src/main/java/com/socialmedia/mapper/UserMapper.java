package com.socialmedia.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.socialmedia.dto.UserDTO;
import com.socialmedia.entity.User;

@Component
public class UserMapper {

	// Convert Entity to DTO

	public  UserDTO entityToDTO(User userEntity) {

		if (userEntity == null)
			return null;

		UserDTO userDto = new UserDTO();

		BeanUtils.copyProperties(userEntity, userDto);

		return userDto;

	}

	// Convert DTO to entity

	public  User dtoToEntity(UserDTO userDTO) {

		if (userDTO == null)
			return null;

		User userEntity = new User();

		BeanUtils.copyProperties(userDTO, userEntity);

		return userEntity;

	}

}
