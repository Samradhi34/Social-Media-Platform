package com.socialmedia.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.socialmedia.dto.PostDTO;
import com.socialmedia.entity.Post;

@Component
public class PostMapper {

	// Convert Entity to DTO

	public PostDTO entityToDTO(Post postEntity) {

		if (postEntity == null)
			return null;

		PostDTO postDTO = new PostDTO();

		BeanUtils.copyProperties(postEntity, postDTO);

		return postDTO;

	}

	// Convert DTO to entity

	public Post dtoToEntity(PostDTO postDTO) {

		if (postDTO == null)
			return null;

		Post postEntity = new Post();

		BeanUtils.copyProperties(postDTO, postEntity);

		return postEntity;

	}

}
