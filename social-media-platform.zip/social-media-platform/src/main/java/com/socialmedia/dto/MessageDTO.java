package com.socialmedia.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MessageDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1268537895016878972L;

	private Long id;

    @NotNull(message = "SenderId is required")
    private Long senderId;

    @NotNull(message = "ReceiverId is required")
    private Long receiverId;

    @NotBlank(message = "Message content is required")
    private String content;

//    @NotNull(message = "Media is required")
//    private MediaResource media;
    
    private LocalDateTime sentAt;
    
    private boolean isRead;

}
