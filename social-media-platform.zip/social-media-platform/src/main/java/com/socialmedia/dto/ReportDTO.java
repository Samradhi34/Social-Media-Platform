package com.socialmedia.dto;

import java.io.Serializable;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2203556044870492034L;

	private Long id;
	
	@NotNull(message = "UserId is required")
	@Min(value = 1, message = "UserId must be greater than 0")

    private Long userId;
	
	@NotNull(message = "PostId is required")
    private Long postId;
    
}
