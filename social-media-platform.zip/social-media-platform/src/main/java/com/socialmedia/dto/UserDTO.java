package com.socialmedia.dto;

import java.io.Serializable;

import com.socialmedia.validation.ValidEmail;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -993591322927663298L;

	private Long id;
	
	@NotBlank(message = "Username is required")
    @Size(min = 3, max = 30, message = "Username must be between 3 and 30 characters")
	private String username;
	
	@NotBlank(message = "Email is required")
	@ValidEmail(message = "Invalid email format")
	private String email;
	
	@NotBlank(message = "Password is required")
    @Size(min = 6, max = 20, message = "Password must be between 6 and 20 characters")
    private String password;
	
	@Pattern(regexp = "Male|Female|Other", message = "Gender must be Male, Female or Other")
	private String gender;
	
//	private Set<Long> savedPostIds;

}
