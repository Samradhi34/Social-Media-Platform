package com.socialmedia.dto;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LikeDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1308307818644650224L;

	private Long id;
	
	@NotNull(message = "UserId is required")
    private Long userId;
	
    private Long postId;
    
    private Long commentId;
    
}
