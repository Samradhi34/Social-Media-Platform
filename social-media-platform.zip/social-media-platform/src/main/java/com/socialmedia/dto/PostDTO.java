package com.socialmedia.dto;

import java.io.Serializable;
import java.util.Set;

import com.socialmedia.entity.MediaResource;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PostDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3830053190388055447L;

	private Long id;

	@NotBlank(message = "Post content is required")
	@Size(max = 3000, message = "Content cannot exceed 3000 characters")
	private String content;
	
	private String tags; 

	@NotNull(message = "Media is required")
	private MediaResource media;

	private boolean isDisabled;

	@NotNull(message = "UserId is required")
	private Long userId;
	
	private Set<Long> likeIds;     
    private Set<Long> commentIds;  
    private Set<Long> reportIds;   
    private Set<Long> repostedByIds;

}
