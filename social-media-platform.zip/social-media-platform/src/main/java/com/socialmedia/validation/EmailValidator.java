package com.socialmedia.validation;

import java.util.regex.Pattern;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * ConstraintValidator - helper class use for set way of validation logic
 */

public class EmailValidator implements ConstraintValidator<ValidEmail, String> {
	
	// Simple regex for email validation
    private static final String EMAIL_REGEX = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";

    private Pattern pattern = Pattern.compile(EMAIL_REGEX);
    
    /**
     * validation logic
     */

    @Override
    public boolean isValid(String email, ConstraintValidatorContext context) {
        if (email == null || email.isBlank()) {
            return true; // Let @NotNull or @NotBlank handle null/empty
        }
        return pattern.matcher(email).matches();
    }

}
