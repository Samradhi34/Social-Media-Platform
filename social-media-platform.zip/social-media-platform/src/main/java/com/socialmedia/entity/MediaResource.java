package com.socialmedia.entity;

import java.io.Serializable;

import com.socialmedia.constants.MediaType;

import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class MediaResource implements Serializable{
	
/**
	 * 
	 */
	private static final long serialVersionUID = 4398287112572880872L;
	

	@NotBlank(message = "MediaUrl is required")
	private String mediaUrl;      // file path
	
	@NotNull(message = "MediaType is required")
	@Enumerated(EnumType.STRING)
	private MediaType mediaType;    // IMAGE, VIDEO, AUDIO, NONE

	public String getPath() {
		return mediaUrl;
	}

}
