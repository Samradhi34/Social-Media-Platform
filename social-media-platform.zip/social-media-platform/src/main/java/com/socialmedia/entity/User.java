package com.socialmedia.entity;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@Data
@Table(name = "users")
@Entity
@EqualsAndHashCode(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
public class User extends CommonModel{


	/**
	 * 
	 */
	private static final long serialVersionUID = -7759594001652286516L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false, unique = true)
	private String username;

	@Column(nullable = false, unique = true)
	private String email;

	@Column(nullable = false)
	private String password;

	private String gender;
	
	/**
	 *  Following: users whom this user follows
	 */
	@ManyToMany(mappedBy = "followers")
	private Set<User> following; 
	
	@EqualsAndHashCode.Exclude // To prevents recursion
	@ToString.Exclude
	@ManyToMany
	@JoinTable(name = "user_followers", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "follower_id"))
	@JsonIgnore // prevent infinite recursion
	private Set<User> followers; // Followers: users who follow this user

	@ManyToMany
	@JsonIgnore
	@JoinTable(name = "user_saved_posts", 
	joinColumns = @JoinColumn(name = "user_id"), 
	inverseJoinColumns = @JoinColumn(name = "post_id"))
	private Set<Post> savedPosts;

}
