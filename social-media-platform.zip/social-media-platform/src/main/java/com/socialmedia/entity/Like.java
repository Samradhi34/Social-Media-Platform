package com.socialmedia.entity;


import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper=false)
@Builder
@Entity
@Table(name = "likes")
public class Like extends CommonModel{
	
	private static final long serialVersionUID = 6912148180769308905L;

	@EmbeddedId              //Prevents duplicate likes
    private LikeId id;
	
	@ManyToOne
	@MapsId("userId") // maps LikeId.userId to user_id column
	@JoinColumn(name = "user_id")         //Creates a foreign key column user-id
	private User user;           
	
	@ManyToOne
	@MapsId("postId") // maps LikeId.postId to post_id column
	@JoinColumn(name = "post_id", nullable = true)   //Creates a foreign key column post_id & This column is optional in DB
	private Post post;
	
	@ManyToOne
	@JoinColumn(name = "comment_id", nullable = true)   //Creates a foreign key column comment-id
	private Comment comment;


}
