package com.socialmedia.entity;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@Entity(name = "Post")
@Table(name = "posts")
public class Post extends CommonModel{

	private static final long serialVersionUID = -1238453772878399365L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false, length = 3000)
	private String content;
	
	private String tags; 
	
	@Embedded
	private MediaResource media;

	/**
	 * post is active/visible,anyone can see it , otherwise it is hidden
	 */
	@Builder.Default
	private boolean isDisabled = false; 
	
	@Lob
	private byte[] data;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user; 

	/**
	 *  Likes on Post
	 */
	@OneToMany(mappedBy = "post", cascade = CascadeType.PERSIST, orphanRemoval = true)
	private Set<Like> likes ; 

	/**
	 *  Comments on post
	 */
	@OneToMany(mappedBy = "post", cascade = CascadeType.PERSIST, orphanRemoval = true)
	@JsonManagedReference   // parent side
	private Set<Comment> comments ; 

	/**
	 *  Reports on the post
	 */
	@OneToMany(mappedBy = "post", cascade = CascadeType.PERSIST, orphanRemoval = true)
	private Set<Report> reports; 

	@ManyToMany
	@JoinTable(
			name = "post_reposts", 
			joinColumns = @JoinColumn(name = "post_id"), 
			inverseJoinColumns = @JoinColumn(name = "user_id")
	)
	
	/**
	 *  Reposts - many users can repost many posts
	 */
	private Set<User> repostedBy; 

}
