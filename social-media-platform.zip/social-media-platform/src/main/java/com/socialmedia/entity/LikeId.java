package com.socialmedia.entity;

import java.io.Serializable;

import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Embeddable
@Data
public class LikeId implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7301740789899516287L;
	private Long userId;
	private Long postId;

}
