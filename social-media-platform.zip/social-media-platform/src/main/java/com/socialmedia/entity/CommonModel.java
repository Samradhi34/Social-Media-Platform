package com.socialmedia.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;

/**
 * It doesn't creates its own table in DB, but help other entities to extend it & It helps to add its feilds in their table
 * @MappedSuperclass 
 */

@Data
@MappedSuperclass
public class CommonModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2219184501121176799L;

	@CreationTimestamp           // automatically set when record is created
	@Column(nullable = true, updatable = false)
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime createdAt;
	
	@UpdateTimestamp
	private LocalDateTime updatedAt;   // whenever post content changes, this auto-updates
	
	@CreationTimestamp
	private LocalDateTime sentAt;
}
