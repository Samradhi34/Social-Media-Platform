package com.socialmedia.locale;

public interface MessageByLocaleService {
	
	/**
	 * Get localized  message for given key
	 * @param id
	 * @param arg
	 * @return
	 */
	String getMessage(String id, Object[] arg);

}
