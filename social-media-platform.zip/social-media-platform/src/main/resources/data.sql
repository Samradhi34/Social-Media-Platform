TRUNCATE TABLE users RESTART IDENTITY CASCADE;


INSERT INTO users (username, email, password) VALUES
('rahul', 'rahul@example.com', 'xyz@1234'),
('aditi', 'aditi@example.com', '123xxx123'),
('vipul', 'vipul@example.com', 'vipul999'),
('yash', 'yash@example.com', '21yash21'),
('samarth', 'samarth@example.com', 'sam1010101'),
('bob', 'bob@example.com', 'securepass'),
('charlie', 'charlie@example.com', 'charliepwd'),
('diana', 'diana@example.com', 'dianapass'),
('ron', 'ron@example.com', 'ron576gs');



